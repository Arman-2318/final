
import React, { useState } from 'react';
import * as data from '../data';
import { FormField, Patient, Ward, Bed, ICU, Staff, Chemist, Billing, BillDetails } from '../types';
import { AddRecordModal } from './AddRecordModal';
import { Button } from './common/Button';

type TableName = 'Patient' | 'Ward' | 'Bed' | 'ICU' | 'Staff' | 'Chemist' | 'Billing' | 'Bill_Details';

const TABS: TableName[] = ['Patient', 'Ward', 'Bed', 'ICU', 'Staff', 'Chemist', 'Billing', 'Bill_Details'];

const formFieldConfig: Record<TableName, FormField[]> = {
    Patient: [
        { name: 'name', label: 'Name', type: 'text', required: true, placeholder: 'e.g., John Doe' },
        { name: 'age', label: 'Age', type: 'number', required: true, placeholder: 'e.g., 42' },
        { name: 'gender', label: 'Gender', type: 'select', required: true, options: ['Male', 'Female', 'Other'] },
        { name: 'contact', label: 'Contact', type: 'text', required: true, placeholder: 'e.g., 9876543210' },
        { name: 'waiting_list', label: 'On Waiting List', type: 'checkbox' },
    ],
    Ward: [
        { name: 'ward_name', label: 'Ward Name', type: 'text', required: true, placeholder: 'e.g., General Ward C' },
        { name: 'total_beds', label: 'Total Beds', type: 'number', required: true, placeholder: 'e.g., 25' },
        { name: 'type', label: 'Type', type: 'select', required: true, options: ['General', 'Private', 'Semi-Private', 'ICU'] },
    ],
    Bed: [
        { name: 'ward_id', label: 'Ward ID', type: 'number', required: true, placeholder: 'e.g., 1' },
        { name: 'patient_id', label: 'Patient ID (if occupied)', type: 'number', placeholder: 'e.g., 1' },
        { name: 'is_occupied', label: 'Is Occupied', type: 'checkbox' },
    ],
    ICU: [
        { name: 'bed_id', label: 'Bed ID', type: 'number', required: true, placeholder: 'e.g., 5' },
        { name: 'ventilator', label: 'On Ventilator', type: 'checkbox' },
        { name: 'oxygen_support', label: 'On Oxygen Support', type: 'checkbox' },
    ],
    Staff: [
        { name: 'name', label: 'Name', type: 'text', required: true, placeholder: 'e.g., Jane Doe' },
        { name: 'role', label: 'Role', type: 'text', required: true, placeholder: 'e.g., Doctor' },
        { name: 'salary', label: 'Salary', type: 'number', required: true, placeholder: 'e.g., 80000' },
    ],
    Chemist: [
        { name: 'name', label: 'Medicine Name', type: 'text', required: true, placeholder: 'e.g., Aspirin 100mg' },
        { name: 'stock', label: 'Stock', type: 'number', required: true, placeholder: 'e.g., 500' },
        { name: 'price', label: 'Price', type: 'number', required: true, placeholder: 'e.g., 15.75' },
        { name: 'expiry_date', label: 'Expiry Date', type: 'date', required: true },
    ],
    Billing: [
        { name: 'patient_id', label: 'Patient ID', type: 'number', required: true, placeholder: 'e.g., 1' },
        { name: 'total_amount', label: 'Total Amount', type: 'number', required: true, placeholder: 'e.g., 2500' },
        { name: 'payment_status', label: 'Payment Status', type: 'select', required: true, options: ['Pending', 'Paid'] },
        { name: 'bill_date', label: 'Bill Date', type: 'date', required: true },
    ],
    Bill_Details: [
        { name: 'bill_id', label: 'Bill ID', type: 'number', required: true, placeholder: 'e.g., 1' },
        { name: 'description', label: 'Description', type: 'text', required: true, placeholder: 'e.g., Room Charges' },
        { name: 'amount', label: 'Amount', type: 'number', required: true, placeholder: 'e.g., 1200' },
    ],
};

const TableHeader: React.FC<{ headers: string[] }> = ({ headers }) => (
    <thead className="bg-base-300">
        <tr>
            {headers.map(header => (
                <th key={header} scope="col" className="px-6 py-3 text-left text-xs font-bold text-text-light uppercase tracking-wider">
                    {header.replace(/_/g, ' ')}
                </th>
            ))}
        </tr>
    </thead>
);

const TableRow: React.FC<{ item: any; columns: string[] }> = ({ item, columns }) => (
    <tr className="even:bg-base-200/50">
        {columns.map(column => (
            <td key={column} className="px-6 py-4 whitespace-nowrap text-sm text-text-light">
                {typeof item[column] === 'boolean' ? (item[column] ? 
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Yes</span> : 
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">No</span>
                    ) : String(item[column])}
            </td>
        ))}
    </tr>
);

export const DatabaseDashboard: React.FC = () => {
    const [activeTab, setActiveTab] = useState<TableName>('Patient');
    const [isModalOpen, setIsModalOpen] = useState(false);

    const [patients, setPatients] = useState<Patient[]>(data.patients);
    const [wards, setWards] = useState<Ward[]>(data.wards);
    const [beds, setBeds] = useState<Bed[]>(data.beds);
    const [icus, setIcus] = useState<ICU[]>(data.icus);
    const [staff, setStaff] = useState<Staff[]>(data.staff);
    const [chemist, setChemist] = useState<Chemist[]>(data.chemist);
    const [billing, setBilling] = useState<Billing[]>(data.billing);
    const [billDetails, setBillDetails] = useState<BillDetails[]>(data.billDetails);

    const handleAddRecord = (record: any) => {
        switch (activeTab) {
            case 'Patient':
                const newPatientId = Math.max(...patients.map(p => p.patient_id), 0) + 1;
                setPatients(prev => [...prev, { ...record, patient_id: newPatientId }]);
                break;
            case 'Ward':
                const newWardId = Math.max(...wards.map(w => w.ward_id), 0) + 1;
                setWards(prev => [...prev, { ...record, ward_id: newWardId }]);
                break;
            case 'Bed':
                 const newBedId = Math.max(...beds.map(b => b.bed_id), 0) + 1;
                 setBeds(prev => [...prev, { ...record, bed_id: newBedId, patient_id: record.patient_id || null }]);
                 break;
            case 'ICU':
                 const newIcuId = Math.max(...icus.map(i => i.icu_id), 0) + 1;
                 setIcus(prev => [...prev, { ...record, icu_id: newIcuId }]);
                 break;
            case 'Staff':
                 const newStaffId = Math.max(...staff.map(s => s.staff_id), 0) + 1;
                 setStaff(prev => [...prev, { ...record, staff_id: newStaffId }]);
                 break;
            case 'Chemist':
                const newMedicineId = Math.max(...chemist.map(c => c.medicine_id), 0) + 1;
                setChemist(prev => [...prev, { ...record, medicine_id: newMedicineId }]);
                break;
            case 'Billing':
                const newBillId = Math.max(...billing.map(b => b.bill_id), 0) + 1;
                setBilling(prev => [...prev, { ...record, bill_id: newBillId }]);
                break;
            case 'Bill_Details':
                const newDetailId = Math.max(...billDetails.map(bd => bd.detail_id), 0) + 1;
                setBillDetails(prev => [...prev, { ...record, detail_id: newDetailId }]);
                break;
        }
        setIsModalOpen(false);
    };

    const renderTable = () => {
        const commonTableProps = {
            className: "min-w-full divide-y divide-gray-200"
        };
        const commonTbodyProps = {
            className: "bg-base-100 divide-y divide-gray-200"
        };

        switch (activeTab) {
            case 'Patient':
                const patientCols = ['patient_id', 'name', 'age', 'gender', 'contact', 'waiting_list'];
                return (
                    <table {...commonTableProps}>
                        <TableHeader headers={patientCols} />
                        <tbody {...commonTbodyProps}>
                            {patients.map(p => <TableRow key={p.patient_id} item={p} columns={patientCols} />)}
                        </tbody>
                    </table>
                );
            case 'Ward':
                const wardCols = ['ward_id', 'ward_name', 'total_beds', 'type'];
                 return (
                    <table {...commonTableProps}>
                        <TableHeader headers={wardCols} />
                        <tbody {...commonTbodyProps}>
                            {wards.map(w => <TableRow key={w.ward_id} item={w} columns={wardCols} />)}
                        </tbody>
                    </table>
                );
            case 'Bed':
                const bedCols = ['bed_id', 'ward_id', 'is_occupied', 'patient_id'];
                return (
                    <table {...commonTableProps}>
                        <TableHeader headers={bedCols} />
                        <tbody {...commonTbodyProps}>
                            {beds.map(b => <TableRow key={b.bed_id} item={b} columns={bedCols} />)}
                        </tbody>
                    </table>
                );
            case 'ICU':
                const icuCols = ['icu_id', 'bed_id', 'ventilator', 'oxygen_support'];
                return (
                    <table {...commonTableProps}>
                        <TableHeader headers={icuCols} />
                        <tbody {...commonTbodyProps}>
                            {icus.map(i => <TableRow key={i.icu_id} item={i} columns={icuCols} />)}
                        </tbody>
                    </table>
                );
            case 'Staff':
                const staffCols = ['staff_id', 'name', 'role', 'salary'];
                return (
                    <table {...commonTableProps}>
                        <TableHeader headers={staffCols} />
                        <tbody {...commonTbodyProps}>
                            {staff.map(s => <TableRow key={s.staff_id} item={s} columns={staffCols} />)}
                        </tbody>
                    </table>
                );
            case 'Chemist':
                const chemistCols = ['medicine_id', 'name', 'stock', 'price', 'expiry_date'];
                return (
                    <table {...commonTableProps}>
                        <TableHeader headers={chemistCols} />
                        <tbody {...commonTbodyProps}>
                            {chemist.map(c => <TableRow key={c.medicine_id} item={c} columns={chemistCols} />)}
                        </tbody>
                    </table>
                );
            case 'Billing':
                const billingCols = ['bill_id', 'patient_id', 'total_amount', 'payment_status', 'bill_date'];
                return (
                    <table {...commonTableProps}>
                        <TableHeader headers={billingCols} />
                        <tbody {...commonTbodyProps}>
                            {billing.map(b => <TableRow key={b.bill_id} item={b} columns={billingCols} />)}
                        </tbody>
                    </table>
                );
            case 'Bill_Details':
                const billDetailsCols = ['detail_id', 'bill_id', 'description', 'amount'];
                return (
                    <table {...commonTableProps}>
                        <TableHeader headers={billDetailsCols} />
                        <tbody {...commonTbodyProps}>
                            {billDetails.map(bd => <TableRow key={bd.detail_id} item={bd} columns={billDetailsCols} />)}
                        </tbody>
                    </table>
                );
            default:
                return null;
        }
    };
    
    return (
        <div>
            <div className="border-b border-gray-200">
                <nav className="-mb-px flex space-x-4 overflow-x-auto" aria-label="Tabs">
                    {TABS.map(tab => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={`${
                                activeTab === tab
                                    ? 'border-primary text-primary'
                                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                            } whitespace-nowrap py-4 px-3 border-b-2 font-medium text-sm transition-colors focus:outline-none`}
                        >
                            {tab.replace('_', ' ')}
                        </button>
                    ))}
                </nav>
            </div>

            <div className="mt-6 mb-4 flex justify-end">
                <Button onClick={() => setIsModalOpen(true)} variant="secondary">
                    Add New {activeTab.replace('_', ' ')}
                </Button>
            </div>

            <div className="overflow-x-auto">
                <div className="align-middle inline-block min-w-full shadow overflow-hidden sm:rounded-lg border border-gray-200/80">
                    {renderTable()}
                </div>
            </div>

            <AddRecordModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSubmit={handleAddRecord}
                tableName={activeTab}
                fields={formFieldConfig[activeTab]}
            />
        </div>
    );
};